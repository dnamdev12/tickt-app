export const SET_LOADING = 'SET_LOADING';
export const SHOW_HIDE_TOAST = 'SHOW_HIDE_TOAST';