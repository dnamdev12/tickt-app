import React from 'react'

const GuestLogin = () => {
    return (
        <div>
            Guest Login
        </div>
    )
}

export default GuestLogin
